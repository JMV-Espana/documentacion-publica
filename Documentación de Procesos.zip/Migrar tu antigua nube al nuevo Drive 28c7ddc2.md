> [!danger]
> En el nuevo Drive, almacenaremos datos sensibles en una unidad aparte.&#x20;
>
> Por favor, consulta la política de Unidades Compartidas: [Unidades Comparitdas: qué y para qué](<Unidades Comparitdas_ qué y para qué 8f5a353d.md?n>)

1. Crea una carpeta en tu antiguo Drive con el nombre “Archivos antiguos”.

![e1ca4761-23d2-4cb1-b22a-57655388c5ae.png](files/a7a3e08d-3a8b-4b6a-a3f9-053f8dfbb030/e1ca4761-23d2-4cb1-b22a-57655388c5ae.png)

<br>

![1413d87f-6c1a-4f3d-84f6-78b629cce68e.png](files/9a86d118-0e0f-42c1-88f2-520ffa5618e1/1413d87f-6c1a-4f3d-84f6-78b629cce68e.png)

<br>

2. Selecciona todos los ficheros de “Mi unidad” usando la tecla Ctrl +A (si haces click en la carpeta Archivos antiguos mientras tienes apretado la tecla Ctrl la deseleccionas) y muévelos a la nueva carpeta nueva.

![e56be5dd-6c8f-4560-a325-9b611abe5986.png](files/bb69c3c0-5968-42f4-80d9-15cab6f29638/e56be5dd-6c8f-4560-a325-9b611abe5986.png)

3. Repite el punto anterior hasta que solamente quede la carpeta Archivos Antiguos.

![219c25b5-e53e-465f-bce0-f99590cc5587.png](files/bc536638-82d3-447b-816e-524f64b2aabf/219c25b5-e53e-465f-bce0-f99590cc5587.png)

4. Una vez ya no quede ningún archivo por mover, descargamos la carpeta. Dependiendo de la cantidad de archivos que tengamos, este proceso puede tardar unos minutos. Puede que también se descarguen varios archivos .zip para dividir la descarga en paquetes más pequeños.

   ![3a5c9136-5e82-40fe-863a-9681ecf9aa58.png](files/a8350989-f499-4c38-a587-762b0535dea0/3a5c9136-5e82-40fe-863a-9681ecf9aa58.png)
5. Cuando se hayan descargado los ficheros, tendremos que ir a la carpeta donde se han descargado y seleccionarlos. Hacemos click con el botón derecho del ratón y seleccionamos la opción “WinRar” y “Extraer aquí”.
6. ![f5a48a67-eab4-4927-a672-c6931e9c269c.png](files/10043ca8-27c7-419a-bc08-d4dc49bc259c/f5a48a67-eab4-4927-a672-c6931e9c269c.png)

   Cuando haya finalizado el proceso, aparecerá la carpeta “Archivos antiguos” esa será la que tenemos que seleccionar para subir en la nueva cuenta.
7. ![ed8535f2-5e8d-4d10-9c5a-b9bafc552c5a.png](files/d4606b05-11ae-4b22-acb9-cc511ec71669/ed8535f2-5e8d-4d10-9c5a-b9bafc552c5a.png)

![31f154e9-5374-4e7d-83e4-0d4a66573112.png](files/47df137b-5afa-4a56-833a-30c0145469ae/31f154e9-5374-4e7d-83e4-0d4a66573112.png)

<br>

> [!info]
> OPCIONAL.&#x20;
>
> En la carpeta de “Compartido conmigo” en el Drive de vuestra cuenta original, podéis tener ficheros que os interese descargaros para guardarlos. Añadirlos a la carpeta descargada antes de subir esta carpeta a la nueva cuenta corporativa.

> [!warning]
> Consulta la política de uso sobre "Mi Unidad" y las UNIDADES COMPARTIDAS
>
> Toda la info aquí: [Unidades Comparitdas: qué y para qué](<Unidades Comparitdas_ qué y para qué 8f5a353d.md?n>)

<br>
