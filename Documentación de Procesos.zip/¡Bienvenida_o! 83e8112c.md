**Welcome to our Process Docs workspace!** This is our source of truth for all information related to our business and IT operations, such as SOPs, process maps, checklists, and more.

Este es el espacio de **Documentación de Procesos**. Aquí encontrarás todas las guías administrativas de JMV: como migrar al nuevo Drive, enviar documentos oficiales, reportes, memorias, etc.

Esta wiki tiene varios apartados, que puedes ver en el panel izquierdo.

- **Procesos**: con los pasos a seguir para lo que necesites.
- **Recursos**: índice de documentos o accesos que pueden serte útiles.
- **Checklists**.

> [!info]
> ¿Preguntas?
>
> Deja un comentario aquí abajo mencionado a [Soporte Operativo](https://app.nuclino.com/groups/5fcae8bd-7449-4244-9957-d2a2b707da7d?mId=tyUAq7ry) y te contestaremos en cuanto lo veamos.

<br>
