# Before the first day

- [ ] Prepare the paperwork:
  - [ ] Insurance forms
  - [ ] W-4
  - [ ] I-9
  - [ ] Non-disclosure agreement
- [ ] Assign a mentor.
- [ ] Discuss role, expectations, and planned projects with the new employee's supervisor.
- [ ] Grant access to relevant tools:
  - [ ] Nuclino
  - [ ] Slack
  - [ ] Intercom
  - [ ] Google Drive
- [ ] Prepare the workstation:
  - [ ] Laptop
  - [ ] Mouse
  - [ ] Headset
  - [ ] Phone
- [ ] Set up an email account.
- [ ] Issue the ID and floor key card.

# First day

- Send out an announcement email to the team introducing the new team member and notifying them of their arrival time.
- Prepare the desk. Put together a welcome swag bag, including:
  - 5 branded pens
  - Notebook
  - T-shirt
  - Mug
- Greet and introduce the new hire to the team.
- Take a tour around the office:
  - New employee's desk
  - Mentor's desk
  - Kitchen

# First week

- [ ] ...
- [ ] ...
- [ ] ...
