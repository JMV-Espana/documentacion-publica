> [!danger]
> Es mucho más efectivo importar la cuenta de Gmail completa, con todo el historial, contactos y nuevos correos. Sigue las instrucciones para hacerlo aquí: [Importar la cuenta de Gmail antigua](<Importar la cuenta de Gmail antigua 58f68d86.md?n>)
>
> Utiliza esta guía solamente si no has podido hacer la importación o quieres seguir recibiendo emails de tu antigua cuenta pasados 30 días desde la importación.

Muchas familias, empresas con las que contratamos servicios, antiguos socios... tienen nuestros emails de centro.

Para que no tengan ningún problema al contactarnos, debemos redirigir esos emails a nuestro nuevo correo de centro jmvesp.org.

Aquí tienes los pasos para hacerlo desde una cuenta de Gmail personal (no institucional).

1. Abre tu antigua cuenta de **Gmail personal** en un ordenador.
2. Haz clic en el icono de **Configuración** (la rueda dentada) en la esquina superior derecha y selecciona **Ver todos los ajustes**.

   ![Screenshot 2026-08-27 at 17.33.07.png](<files/29f7e9d1-2e18-4c68-b82c-14d4b154f9fe/Screenshot 2026-08-27 at 17.33.07.png>)
3. Entra en la pestaña **Reenvío y correo POP/IMAP**.

   ![imagen.png](files/307491e8-410d-45a8-a035-f67202f8f780/imagen.png)
4. En la sección "Reenvío", haz clic en el botón **Agregar una dirección de reenvío**.

   ![imagen.png](files/eeb73853-b3e7-4c64-9db5-121080b7be24/imagen.png)
5. Escribe tu **dirección de correo corporativo (la que termina en jmvesp.org)** y haz clic en *Siguiente*, luego en *Continuar* y en *Aceptar*. Gmail te pedirá verificar tu identidad mediante contraseña, 2FA o passkey según tengas configurado.

   ![imagen.png](files/d115f0a9-6449-4bfe-9a85-b0165ea8a57b/imagen.png)
6. Ve a la bandeja de entrada de tu **correo corporativo** y busca el mensaje de confirmación de Google. Haz clic en el **vínculo de verificación** que contiene ese correo.
7. Regresa a la pestaña de configuración en tu **Gmail personal**, actualiza el navegador y selecciona la opción **Reenviar una copia del correo entrante a...**.

   ![imagen.png](files/81cf9e64-82b1-40e2-8159-5f41e558824f/imagen.png)
8. Elige qué quieres hacer con el correo original. Te recomendamos "archivar la copia de Gmail".&#x20;
9. Haz clic en **Guardar los cambios** al final de la página (tendrás que hacer scroll hacia abajo)

   ![Screenshot 2026-08-27 at 17.42.33.png](<files/a386150a-d5be-497e-95cd-147c9c2d2bea/Screenshot 2026-08-27 at 17.42.33.png>)

> [!info]
> Te recomendamos que también migres tu bandeja de entrada. Para ello, mira la guía [Importar la cuenta de Gmail antigua](<Importar la cuenta de Gmail antigua 58f68d86.md?n>)

<br>
